DROP TABLE IF EXISTS meta_logs_table CASCADE;

CREATE TABLE meta_logs_table
(
   id               integer,
   change_pass      varchar(5),
   log_table        varchar(50),
   log_description  text,
   log_pid          integer
);



COMMENT ON COLUMN meta_logs_table.id IS 'id for user.';
COMMENT ON COLUMN meta_logs_table.change_pass IS 'value for change password.';
COMMENT ON COLUMN meta_logs_table.log_table IS 'log name of purpose.';
COMMENT ON COLUMN meta_logs_table.log_description IS 'description.';
COMMENT ON COLUMN meta_logs_table.log_pid IS 'process id.';



GRANT REFERENCES, INSERT, SELECT ON meta_logs_table TO test;
GRANT UPDATE, INSERT, SELECT ON meta_logs_table TO user_1;
GRANT REFERENCES, SELECT ON meta_logs_table TO user_2;


COMMIT;


--------------------------------------------------------------------------------------------------


INSERT INTO meta_logs_table (id, change_pass, log_table, log_description, log_pid)
VALUES ('1', 'pass1', 'test', 'test for change_pass', '1');

