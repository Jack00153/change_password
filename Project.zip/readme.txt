Example usage of sql script to automate password change for user using Postgres database and TimescaleDB framework.

programs used:

- Postgres 14.7
- TimescaleDB 2.10.3
- Workbench 
