DO
$do$
BEGIN
   IF EXISTS 
   (
      SELECT FROM pg_catalog.pg_roles WHERE rolname = 'test'  
      INTERSECT
      SELECT FROM public.meta_logs_table WHERE change_pass = 'pass1')
      THEN
      RAISE NOTICE 'User "test" already has new_pass@test1.';
   ELSE
      RAISE NOTICE 'User "test" already has new_pass@test2.';
   END IF;
END
$do$;

