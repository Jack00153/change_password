CREATE OR REPLACE PROCEDURE change_password(job_id int, config jsonb) LANGUAGE PLPGSQL AS
$$
BEGIN
  RAISE NOTICE 'executing process % with configuration %', job_id, config;
  
IF EXISTS (
      SELECT FROM pg_catalog.pg_roles WHERE rolname = 'test'  
      INTERSECT
      SELECT FROM public.meta_logs_table WHERE change_pass = 'pass1')
      THEN
      ALTER USER test WITH PASSWORD 'new_pass@test1';
      UPDATE meta_logs_table
      SET change_pass = 'pass2'
      WHERE id = '1'
      AND change_pass = 'pass1'
      AND log_table = 'test'
      AND log_description = 'test for change_pass'
      AND log_pid = '1';
      ELSE
      ALTER USER test WITH PASSWORD 'new_pass@test2';
      UPDATE meta_logs_table
      SET change_pass = 'pass1'
      WHERE id = '1'
      AND change_pass = 'pass2'
      AND log_table = 'test'
      AND log_description = 'test for change_pass'
      AND log_pid = '1';
END IF;

END
$$;

COMMIT;

