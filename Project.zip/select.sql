SELECT add_job('change_password','10s', scheduled => true);

SELECT alter_job(1009, scheduled => false);

SELECT delete_job(1009);

SELECT * FROM timescaledb_information.jobs;

SELECT * FROM pg_catalog.pg_roles WHERE rolname = 'test';

SELECT rolname, rolpassword FROM pg_authid where rolname='test';

